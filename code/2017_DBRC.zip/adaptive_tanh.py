'''
Author: Di Hu (dtaoo.github.io)
Paper : Deep Binary Reconstruction for Cross-modal Hashing 
Date  : 4.20.2017
'''

from keras import backend as K
from keras.engine.topology import Layer
from keras import initializations, regularizers
import tensorflow as tf

class ATanh(Layer):
    '''Adaptive tanh activation function:
    `f(x) = tanh(alphas*x)'
    where `alphas` is a learned array with the same shape as x.

    # Input shape
        Arbitrary. Use the keyword argument `input_shape`
        (tuple of integers, does not include the samples axis)
        when using this layer as the first layer in a model.

    # Output shape
        Same shape as the input.

    # Arguments
        init: initialization function for the weights.
        weights: initial weights, as a list of a single Numpy array.
    '''

    def __init__(self, init='one', weights=None, **kwargs):
        self.supports_masking = True
        self.__name__='ATanh'
        self.init = initializations.get(init)
        self.initial_weights = weights
        super(ATanh, self).__init__(**kwargs)

    def build(self, input_shape):
        self.alphas = self.init(input_shape[1:],
                                name='{}_alphas'.format(self.name))
        self.trainable_weights = [self.alphas]

        if self.initial_weights is not None:
            self.set_weights(self.initial_weights)
            del self.initial_weights

    def call(self, x, mask=None):
        activation = tf.nn.tanh(self.alphas * x)
        return activation

    def get_config(self):
        config = {'init': self.init.__name__}
        base_config = super(ATanh, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


class thresLinear(Layer):
    '''Thresholding tanh activation function:
    a fixed modified tanh activation function controlled by theta

    # Input shape
        Arbitrary. Use the keyword argument `input_shape`
        (tuple of integers, does not include the samples axis)
        when using this layer as the first layer in a model.

    # Output shape
        Same shape as the input.

    # Arguments
        init: initialization function for the weights.
        theta: a thresholding value
    '''

    def __init__(self, theta=0.01, **kwargs):
        self.supports_masking = True
        self.__name__='ThresLinear'
        self.theta = K.cast_to_floatx(theta)
        super(thresLinear, self).__init__(**kwargs)

    def call(self, x, mask=None):
        forepart = K.cast(x > self.theta, K.floatx()) * (0.1*x + 0.999)
        middlepart = K.cast(x < self.theta, K.floatx()) * K.cast(x > -self.theta, K.floatx())  * 100 * x
        latterpart = K.cast(x < -self.theta, K.floatx()) * (0.1*x - 0.999)

        return forepart+middlepart+latterpart


    def get_config(self):
        config = {'theta': float(self.theta)}
        base_config = super(thresLinear, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))



class ATanhRe(Layer):
    '''Adaptive tanh activation function with regularizer on alpha
    `The function in the paper "Deep Binary Reconstruction for Cross-modal Hashing"

    where `alphas` is a learned array with the same shape as x.

    # Input shape
        Arbitrary. Use the keyword argument `input_shape`
        (tuple of integers, does not include the samples axis)
        when using this layer as the first layer in a model.

    # Output shape
        Same shape as the input.

    # Arguments
        init: initialization function for the weights.
        weights: initial weights, as a list of a single Numpy array.
        alpha_regularizer: such as l2 regularizer
    '''

    def __init__(self, init='one', weights=None, alpha_regularizer=None, **kwargs):
        self.supports_masking = True
        self.__name__='ATanhRe'
        self.init = initializations.get(init)
        self.initial_weights = weights
        self.alpha_regularizer = regularizers.get(alpha_regularizer)
        super(ATanhRe, self).__init__(**kwargs)

    def build(self, input_shape):
        self.alphas = self.init(input_shape[1:],
                                name='{}_alphas'.format(self.name))
        self.trainable_weights = [self.alphas]

        if self.initial_weights is not None:
            self.set_weights(self.initial_weights)
            del self.initial_weights

        self.regularizers = []
        if self.alpha_regularizer:
            self.alpha_regularizer.set_param(1/self.alphas)
            self.regularizers.append(self.alpha_regularizer)

    def call(self, x, mask=None):
        activation = tf.nn.tanh(self.alphas * x)
        return activation

    def get_config(self):
        config = {'init': self.init.__name__,
                  'alpha_regularizer': self.alpha_regularizer.get_config() if self.alpha_regularizer else None}
        return dict(list(config.items()))
